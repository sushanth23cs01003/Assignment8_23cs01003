#include <stdio.h>

int main()
{

    
    char s1[30];
    char s2[10];
    gets(s1);
    printf("%s\n",s1);
    gets(s2);
    printf("%s\n",s2);
    int l1 = strlen(s1);
    int l2 = strlen(s2);
    for(int i=0 ; i<=l2;i++){
        s1[l1+i]= s2[i];
    }
    printf("%s",s1);
    return 0;
}
